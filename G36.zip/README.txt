Steps for testing:
1. Open and build the PADI_DTMS.sln
2. (Optional) Adjust the default configuration parameters in:
- PADI_CLIENT/bin/Debug/PADI_CLIENT.exe.config (Master IP/Port, sleep, etc)
- PADI_DTMS\PADI_OBJECT_SERVER\bin\Debug\PADI_OBJECT_SERVER.exe.config
3. Startup Master, then Object Server, then Client
